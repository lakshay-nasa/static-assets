---
sidebar_position: 47
description: >-
  Data Platforms represent source systems like Snowflake, BigQuery, Kafka, or
  Looker that host datasets, dashboards, and other assets in DataHub.
title: Data Platform
slug: /generated/metamodel/entities/dataplatform
custom_edit_url: null
---
# Data Platform

A Data Platform is a metadata entity that represents a source system, technology, or tool that contains and manages data assets. Data Platforms are the foundational building blocks in DataHub's metadata model, serving as the namespace and classification system for all datasets, dashboards, charts, jobs, and other data assets.

Examples of data platforms include databases (MySQL, PostgreSQL, Oracle), data warehouses (Snowflake, BigQuery, Redshift), BI tools (Looker, Tableau, Power BI), data lakes (S3, HDFS), message brokers (Kafka), and many other systems where data resides or flows through.

## Identity

A Data Platform is uniquely identified by a single component:

- **platformName**: The standardized name of the technology (e.g., "mysql", "snowflake", "looker", "kafka")

The URN structure for a Data Platform is:

```
urn:li:dataPlatform:<platformName>
```

### Examples

```
urn:li:dataPlatform:mysql
urn:li:dataPlatform:snowflake
urn:li:dataPlatform:bigquery
urn:li:dataPlatform:looker
urn:li:dataPlatform:kafka
urn:li:dataPlatform:s3
urn:li:dataPlatform:dbt
```

### Platform Name Conventions

Platform names follow these conventions:

- **Lowercase**: All platform names are lowercase (e.g., "bigquery" not "BigQuery")
- **No spaces**: Use hyphens for multi-word names (e.g., "azure-ad" not "Azure AD")
- **Technology-specific**: Name represents the specific technology, not a vendor or product line
- **Standardized**: DataHub maintains a canonical list of platform names to ensure consistency

The complete list of officially supported data platforms is maintained in DataHub's [data-platforms.yaml](https://github.com/datahub-project/datahub/blob/master/metadata-service/configuration/src/main/resources/bootstrap_mcps/data-platforms.yaml) bootstrap configuration.

### Custom Platforms

While DataHub ships with 100+ pre-defined platforms, you can create custom platform entities for:

- In-house or proprietary data systems
- New technologies not yet in the official list
- Logical groupings of related systems
- Platform variations with specific configurations

When creating custom platforms, follow the naming conventions above and ensure uniqueness across your DataHub instance.

## Important Capabilities

### Platform Information

The `dataPlatformInfo` aspect contains the core metadata about a data platform:

- **name**: The canonical name of the platform (max 15 characters, searchable)
- **displayName**: A user-friendly display name for the platform (e.g., "Google BigQuery" for platform "bigquery")
- **type**: The category of platform from the PlatformType enumeration
- **datasetNameDelimiter**: The character used to separate components in dataset names (e.g., "." for Oracle, "/" for HDFS)
- **logoUrl**: Optional URL to a logo image representing the platform

#### Platform Types

Data platforms are classified into these categories:

- **RELATIONAL_DB**: Traditional relational databases (MySQL, PostgreSQL, Oracle, SQL Server)
- **OLAP_DATASTORE**: Online analytical processing systems (Pinot, Druid, ClickHouse)
- **KEY_VALUE_STORE**: Key-value and NoSQL databases (Redis, DynamoDB, Cassandra)
- **SEARCH_ENGINE**: Search and indexing platforms (Elasticsearch, Solr)
- **MESSAGE_BROKER**: Event streaming and messaging systems (Kafka, Pulsar, RabbitMQ)
- **FILE_SYSTEM**: Distributed file systems (HDFS, NFS, local file systems)
- **OBJECT_STORE**: Cloud object storage (S3, GCS, Azure Blob Storage)
- **QUERY_ENGINE**: SQL query engines (Presto, Trino, Athena, Hive)
- **OTHERS**: Other platform types including BI tools, orchestrators, data catalogs, and specialized systems

The platform type helps DataHub understand how to interact with the platform and what kinds of metadata are expected.

The following code snippet shows you how to create a custom Data Platform.

<details>
<summary>Python SDK: Create a Data Platform</summary>

```python
# Inlined from /metadata-ingestion/examples/library/data_platform_create.py
# metadata-ingestion/examples/library/data_platform_create.py
import logging
import os

from datahub.emitter.mcp import MetadataChangeProposalWrapper
from datahub.emitter.rest_emitter import DatahubRestEmitter
from datahub.metadata.schema_classes import (
    DataPlatformInfoClass,
)

log = logging.getLogger(__name__)
logging.basicConfig(level=logging.INFO)

gms_server = os.getenv("DATAHUB_GMS_URL", "http://localhost:8080")
token = os.getenv("DATAHUB_GMS_TOKEN")
emitter = DatahubRestEmitter(gms_server=gms_server, token=token)

platform_urn = "urn:li:dataPlatform:customdb"

platform_info = DataPlatformInfoClass(
    name="customdb",
    displayName="Custom Database Platform",
    type="RELATIONAL_DB",
    datasetNameDelimiter=".",
    logoUrl="https://company.com/logos/customdb.png",
)

event = MetadataChangeProposalWrapper(
    entityUrn=platform_urn,
    aspect=platform_info,
)

emitter.emit(event)
log.info(f"Created data platform {platform_urn}")

```

</details>

### Dataset Name Delimiter

The `datasetNameDelimiter` field is critical for understanding dataset naming conventions on each platform:

- **"."**: Used by most relational databases (e.g., `database.schema.table` in PostgreSQL)
- **"/"**: Used by file systems (e.g., `/data/warehouse/customers` in HDFS)
- **""** (empty string): Used when dataset names are flat without hierarchy

This delimiter helps DataHub:

- Parse dataset names correctly
- Build browse paths for hierarchical navigation
- Display dataset names in a user-friendly format
- Generate proper URNs for datasets on the platform

### Logo URL

Platforms can have custom logos displayed in the DataHub UI through the `logoUrl` field. This helps users quickly recognize platforms visually. DataHub ships with built-in logos for all officially supported platforms, but custom platforms can specify their own logo URLs.

## Integration Points

### Relationship with Datasets

Data Platforms are the parent entity for all datasets. Every dataset URN includes a platform reference:

```
urn:li:dataset:(urn:li:dataPlatform:snowflake,database.schema.table,PROD)
```

This relationship enables:

- **Discovery**: Find all datasets belonging to a specific platform
- **Governance**: Apply platform-level policies and access controls
- **Lineage**: Track data movement between different platforms
- **Inventory**: Understand the distribution of data across your technology stack

### Relationship with Other Entities

Beyond datasets, platforms are referenced by many other entity types:

- **Dashboards**: BI dashboards from platforms like Looker, Tableau, Superset
- **Charts**: Visualizations from BI platforms
- **DataFlows**: Orchestration workflows from Airflow, Prefect, Dagster
- **DataJobs**: Individual tasks or jobs within data pipelines
- **ML Models**: Machine learning models from platforms like SageMaker, MLflow
- **DataProcesses**: Streaming processes from platforms like Flink, Spark

All of these entities include a platform reference in their URNs, creating a comprehensive technology inventory.

### Platform Instances

For organizations running multiple instances of the same platform (e.g., multiple Snowflake accounts, multiple production BigQuery projects), DataHub provides a `dataPlatformInstance` entity. This allows distinguishing between:

- Platform: The technology itself (e.g., "snowflake")
- Platform Instance: A specific deployment of that technology (e.g., "snowflake-prod-us-west", "snowflake-dev-eu")

Platform instances reference their parent platform and add deployment-specific metadata like environment, region, or account information.

<details>
<summary>Python SDK: Create a Platform Instance</summary>

```python
# Inlined from /metadata-ingestion/examples/library/platform_instance_create.py
# metadata-ingestion/examples/library/platform_instance_create.py
import os

import datahub.emitter.mce_builder as builder
from datahub.emitter.mcp import MetadataChangeProposalWrapper
from datahub.emitter.rest_emitter import DatahubRestEmitter
from datahub.metadata.schema_classes import DataPlatformInstancePropertiesClass

# Create the platform instance URN
platform_instance_urn = builder.make_dataplatform_instance_urn(
    platform="mysql", instance="production-mysql-cluster"
)

# Define properties for the platform instance
platform_properties = DataPlatformInstancePropertiesClass(
    name="Production MySQL Cluster",
    description="Primary MySQL database cluster serving production workloads in US West region",
    customProperties={
        "region": "us-west-2",
        "environment": "production",
        "cluster_size": "3-node",
        "version": "8.0.35",
    },
    externalUrl="https://cloud.mysql.com/console/clusters/prod-cluster",
)

# Create metadata change proposal
platform_instance_mcp = MetadataChangeProposalWrapper(
    entityUrn=platform_instance_urn,
    aspect=platform_properties,
)

# Emit metadata to DataHub
gms_server = os.getenv("DATAHUB_GMS_URL", "http://localhost:8080")
token = os.getenv("DATAHUB_GMS_TOKEN")
emitter = DatahubRestEmitter(gms_server=gms_server, token=token)
emitter.emit_mcp(platform_instance_mcp)

print(f"Created platform instance: {platform_instance_urn}")

```

</details>

### Ingestion Sources

Data Platforms are typically created automatically through two mechanisms:

1. **Bootstrap Data**: When DataHub starts, it loads ~100 pre-defined platforms from the bootstrap configuration
2. **Ingestion Connectors**: When you run an ingestion source (e.g., the Snowflake connector), it automatically creates platform references for any assets it ingests

You rarely need to manually create platform entities unless you're adding a custom or in-house system not covered by the standard bootstrap list.

### Search and Discovery

Platforms are fully searchable in DataHub:

- **Platform Name Search**: Find platforms by their canonical name
- **Display Name Search**: Search using user-friendly display names
- **Platform Filtering**: Filter datasets and other entities by platform
- **Platform Browse**: Navigate through entities organized by platform

This enables users to explore the data landscape from a platform-centric view.

### GraphQL API

Data Platforms can be queried through the GraphQL API to retrieve:

- Platform metadata (name, type, logo)
- Counts of entities on the platform
- Platform configuration information

While platforms are rarely created via GraphQL (since they're mostly bootstrap data), the API enables programmatic access to platform information.

## Notable Exceptions

### Bootstrap vs Custom Platforms

DataHub makes a distinction between:

- **Bootstrap Platforms**: The ~100 platforms loaded at startup, maintained by the DataHub project
- **Custom Platforms**: Platforms you create for your own use cases

Bootstrap platforms:

- Have official logos and display names
- Are maintained across DataHub upgrades
- Are tested with DataHub's ingestion connectors
- Follow consistent naming conventions

Custom platforms:

- May not have logos (unless you provide logoUrl)
- Are your responsibility to maintain
- May not have pre-built ingestion connectors
- Should follow the same naming conventions to avoid confusion

### Platform Name Immutability

Once a platform is created and assets are associated with it, the platform name becomes immutable for practical purposes. Changing a platform name would require:

- Migrating all dataset URNs that reference the platform
- Updating all lineage edges
- Re-ingesting all metadata from that platform

If you need to rename a platform, it's generally easier to:

1. Create a new platform with the desired name
2. Re-ingest all assets using the new platform name
3. Deprecate or delete the old platform

### Platform Name Length Limit

Platform names are limited to 15 characters (enforced by `@validate.strlen.max = 15`). This is a legacy constraint that ensures platform names are concise and fit well in URNs and UI displays.

If your platform's natural name exceeds 15 characters, use an abbreviation or acronym:

- "azure-synapse" → "synapse"
- "amazon-redshift" → "redshift"
- "google-bigquery" → "bigquery"

The full name can go in the `displayName` field without length restrictions.

### Case Sensitivity

Platform names are case-sensitive in URNs but conventionally always lowercase. Avoid creating platforms that differ only in case (e.g., "MySQL" and "mysql") as this will cause confusion and potential URN conflicts.

### Platform Types Are Descriptive, Not Functional

The `type` field (FILE_SYSTEM, RELATIONAL_DB, etc.) is primarily for classification and display purposes. DataHub does not enforce different behaviors based on platform type. Two platforms of different types are treated the same way by the system.

However, connectors and ingestion logic may use platform type to determine:

- What metadata to extract
- How to parse dataset names
- What lineage patterns to expect
- What profiling or usage collection is possible

## Common Platform Categories

### Databases and Data Warehouses

**RELATIONAL_DB platforms**: MySQL, PostgreSQL, Oracle, SQL Server, MariaDB, DB2

**OLAP_DATASTORE platforms**: Snowflake, BigQuery, Redshift, Clickhouse, Pinot, Druid

These platforms typically have:

- Hierarchical dataset names (database.schema.table)
- "." as the delimiter
- Schema metadata (columns, types, constraints)
- Query log metadata for usage and lineage

### Business Intelligence Tools

**OTHERS platform type** (BI-specific): Looker, Tableau, Power BI, Metabase, Superset, Mode

These platforms typically have:

- Dashboard and chart entities
- Lineage from dashboards to underlying datasets
- Usage statistics for views and interactions
- Metadata about report authors and schedules

### Data Lakes and Object Stores

**OBJECT_STORE platforms**: S3, GCS, Azure Blob Storage, MinIO

**FILE_SYSTEM platforms**: HDFS, NFS, Azure Data Lake

These platforms typically have:

- "/" as the delimiter
- File-based datasets (Parquet, Avro, CSV, JSON)
- Path-based naming conventions
- Schema-on-read metadata

### Streaming Platforms

**MESSAGE_BROKER platforms**: Kafka, Pulsar, Kinesis, Event Hubs, RabbitMQ

These platforms typically have:

- Topic or stream datasets
- Schema registry integration
- Real-time lineage tracking
- Throughput and lag metrics

### Orchestration and Pipeline Tools

**OTHERS platform type** (orchestration-specific): Airflow, Prefect, Dagster, Luigi, Argo

These platforms typically have:

- DataFlow (pipeline) and DataJob (task) entities
- DAG structures and dependencies
- Execution statistics and run history
- Lineage based on job dependencies

### Transformation Tools

**OTHERS platform type** (transformation-specific): dbt, Spark, Flink, Databricks

These platforms typically have:

- Strong column-level lineage
- Transformation logic metadata
- Model/job entities
- Test and documentation metadata

## Use Cases

Data Platforms enable several critical use cases in DataHub:

1. **Technology Inventory**: Understand what platforms your organization uses and how extensively
2. **Platform Governance**: Apply policies and access controls at the platform level
3. **Migration Planning**: Identify datasets to migrate when consolidating or replacing platforms
4. **Cost Optimization**: Track which platforms host the most/least used data
5. **Multi-Platform Lineage**: Trace data flows across different technologies in your data ecosystem
6. **Technology Standardization**: Enforce or monitor adoption of approved platforms
7. **Impact Analysis**: Understand the blast radius of platform outages or changes
8. **Discovery Navigation**: Browse and filter assets by platform for easier discovery

By establishing platforms as first-class entities, DataHub provides a comprehensive view of your organization's data technology landscape.

import Tabs from '@theme/Tabs';
import TabItem from '@theme/TabItem';

## Technical Reference Guide

The sections above provide an overview of how to use this entity. The following sections provide detailed technical information about how metadata is stored and represented in DataHub.

**Aspects** are the individual pieces of metadata that can be attached to an entity. Each aspect contains specific information (like ownership, tags, or properties) and is stored as a separate record, allowing for flexible and incremental metadata updates.

**Relationships** show how this entity connects to other entities in the metadata graph. These connections are derived from the fields within each aspect and form the foundation of DataHub's knowledge graph.

### Reading the Field Tables

Each aspect's field table includes an **Annotations** column that provides additional metadata about how fields are used:

- **⚠️ Deprecated**: This field is deprecated and may be removed in a future version. Check the description for the recommended alternative
- **Searchable**: This field is indexed and can be searched in DataHub's search interface
- **Searchable (fieldname)**: When the field name in parentheses is shown, it indicates the field is indexed under a different name in the search index. For example, `dashboardTool` is indexed as `tool`
- **→ RelationshipName**: This field creates a relationship to another entity. The arrow indicates this field contains a reference (URN) to another entity, and the name indicates the type of relationship (e.g., `→ Contains`, `→ OwnedBy`)

Fields with complex types (like `Edge`, `AuditStamp`) link to their definitions in the [Common Types](#common-types) section below.

### Aspects

#### dataPlatformKey
Key for a Data Platform

<Tabs>
<TabItem value="fields" label="Fields" default>


| Field | Type | Required | Description | Annotations |
|-------|------|----------|-------------|-------------|
| platformName | string | ✓ | Data platform name i.e. hdfs, oracle, espresso |  |

</TabItem>
<TabItem value="raw" label="Raw Schema">

```javascript
{
  "type": "record",
  "Aspect": {
    "name": "dataPlatformKey"
  },
  "name": "DataPlatformKey",
  "namespace": "com.linkedin.metadata.key",
  "fields": [
    {
      "type": "string",
      "name": "platformName",
      "doc": "Data platform name i.e. hdfs, oracle, espresso"
    }
  ],
  "doc": "Key for a Data Platform"
}
```

</TabItem>
</Tabs>


#### dataPlatformInfo
Information about a data platform

<Tabs>
<TabItem value="fields" label="Fields" default>


| Field | Type | Required | Description | Annotations |
|-------|------|----------|-------------|-------------|
| name | string | ✓ | Name of the data platform | Searchable |
| displayName | string |  | The name that will be used for displaying a platform type. | Searchable |
| type | PlatformType | ✓ | Platform type this data platform describes |  |
| datasetNameDelimiter | string | ✓ | The delimiter in the dataset names on the data platform, e.g. '/' for HDFS and '.' for Oracle |  |
| logoUrl | string |  | The URL for a logo associated with the platform |  |

</TabItem>
<TabItem value="raw" label="Raw Schema">

```javascript
{
  "type": "record",
  "Aspect": {
    "name": "dataPlatformInfo"
  },
  "name": "DataPlatformInfo",
  "namespace": "com.linkedin.dataplatform",
  "fields": [
    {
      "Searchable": {
        "boostScore": 10.0,
        "enableAutocomplete": false,
        "fieldNameAliases": [
          "_entityName"
        ],
        "fieldType": "WORD_GRAM",
        "searchLabel": "entityName",
        "searchTier": 1
      },
      "validate": {
        "strlen": {
          "max": 15
        }
      },
      "type": "string",
      "name": "name",
      "doc": "Name of the data platform"
    },
    {
      "Searchable": {
        "boostScore": 10.0,
        "enableAutocomplete": true,
        "fieldType": "WORD_GRAM"
      },
      "type": [
        "null",
        "string"
      ],
      "name": "displayName",
      "default": null,
      "doc": "The name that will be used for displaying a platform type."
    },
    {
      "type": {
        "type": "enum",
        "symbolDocs": {
          "FILE_SYSTEM": "Value for a file system, e.g. hdfs",
          "KEY_VALUE_STORE": "Value for a key value store, e.g. espresso, voldemort",
          "MESSAGE_BROKER": "Value for a message broker, e.g. kafka",
          "OBJECT_STORE": "Value for an object store, e.g. ambry",
          "OLAP_DATASTORE": "Value for an OLAP datastore, e.g. pinot",
          "OTHERS": "Value for other platforms, e.g salesforce, dovetail",
          "QUERY_ENGINE": "Value for a query engine, e.g. presto",
          "RELATIONAL_DB": "Value for a relational database, e.g. oracle, mysql",
          "SEARCH_ENGINE": "Value for a search engine, e.g seas"
        },
        "name": "PlatformType",
        "namespace": "com.linkedin.dataplatform",
        "symbols": [
          "FILE_SYSTEM",
          "KEY_VALUE_STORE",
          "MESSAGE_BROKER",
          "OBJECT_STORE",
          "OLAP_DATASTORE",
          "OTHERS",
          "QUERY_ENGINE",
          "RELATIONAL_DB",
          "SEARCH_ENGINE"
        ],
        "doc": "Platform types available at LinkedIn"
      },
      "name": "type",
      "doc": "Platform type this data platform describes"
    },
    {
      "type": "string",
      "name": "datasetNameDelimiter",
      "doc": "The delimiter in the dataset names on the data platform, e.g. '/' for HDFS and '.' for Oracle"
    },
    {
      "java": {
        "class": "com.linkedin.common.url.Url",
        "coercerClass": "com.linkedin.common.url.UrlCoercer"
      },
      "type": [
        "null",
        "string"
      ],
      "name": "logoUrl",
      "default": null,
      "doc": "The URL for a logo associated with the platform"
    }
  ],
  "doc": "Information about a data platform"
}
```

</TabItem>
</Tabs>


### Relationships

### [Global Metadata Model](https://github.com/datahub-project/static-assets/raw/main/imgs/datahub-metadata-model.png)
![Global Graph](https://github.com/datahub-project/static-assets/raw/main/imgs/datahub-metadata-model.png)


:::note 💡 **Contributing to this documentation**
This page is auto-generated from the underlying source code. To make changes, please edit the relevant source files in the [metadata-models](https://github.com/datahub-project/datahub/tree/master/metadata-models) directory. 

**Tip:** For quick typo fixes or documentation updates, you can click the ✏️ **Edit** icon directly in the GitHub UI to open a Pull Request. For larger changes and PR naming conventions, please refer to our [Contributing Guide](/docs/contributing).
:::
