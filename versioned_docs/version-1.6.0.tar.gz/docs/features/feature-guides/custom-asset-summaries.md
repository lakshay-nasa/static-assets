---
title: Asset Summaries
description: >-
  Customize the Summary tab for Domains, Data Products, and Glossary Terms in
  DataHub to create curated discovery experiences.
sidebar_label: Asset Summaries
slug: /features/feature-guides/custom-asset-summaries
custom_edit_url: >-
  https://github.com/datahub-project/datahub/blob/master/docs/features/feature-guides/custom-asset-summaries.md
---

import FeatureAvailability from '@site/src/components/FeatureAvailability';

# Asset Summaries

<FeatureAvailability saasOnly />

DataHub's **Asset Summaries** enable organizations to create tailored, curated discovery experiences for their most important assets by customizing the Summary tab view that users see when browsing Domains, Data Products, Glossary Terms, Glossary Term Groups, and Datasets.

<p align="center">
  <img
       width="70%"  
       src="https://raw.githubusercontent.com/datahub-project/static-assets/refs/heads/main/imgs/summary/summary-overview.png"
       alt="Default custom asset summary page"/>
</p>

:::info Supported Asset Types
Asset Summaries are currently supported for:

- **Logical Assets**: Domains, Data Products, Glossary Terms, and Glossary Term Groups - these help organize and group your physical data assets within DataHub
- **Physical Assets**: Datasets - providing a comprehensive view of your actual data tables and collections
  :::

## Why Use Asset Summaries?

Asset Summaries transform how your team discovers and navigates key organizational assets by enabling you to:

- **Improve Asset Discoverability**: Highlight the most relevant information about your domains, data products, and glossary terms right on the Summary tab
- **Create Owner-Driven Experiences**: Asset owners can curate what information is most important for their users to see
- **Reduce Navigation Time**: Surface key details, documentation, and related assets without requiring users to click through multiple tabs
- **Standardize Asset Presentation**: Ensure consistent, professional presentation of your most important organizational constructs

Whether you're a domain owner wanting to highlight key data products, a data product manager showcasing important assets, a data steward organizing glossary terms, or a data owner presenting dataset details, Asset Summaries put the most relevant information front and center.

## What's Included

Asset Summaries consist of three customizable sections that you can tailor to your asset's specific needs:

### Summary Page Header

The header section showcases key properties about your asset for immediate visibility. By default, this includes:

- **Ownership information** - Who owns and manages this asset
- **Creation date** - When the asset was established
- **Tags** - Asset classifications (available for assets that support tagging)
- **Glossary terms** - Business context and definitions applied to the asset
- **Domain association** - Organizational placement
- **Structured properties** - Custom metadata fields you want to highlight

You can customize this section to show the properties most relevant to your users, including removing default properties or adding new ones. Note that property availability depends on what each asset type supports - for example, not all logical asset types currently support tags.

### Documentation and Links Section

This section brings documentation capabilities directly to the Summary tab for easy access:

- **Rich text documentation** - Add, edit, and format detailed descriptions about your asset
- **Resource links** - Include links to external documentation, dashboards, tools, or other relevant resources
- **Quick access** - Users no longer need to navigate to a separate Documentation tab

### Module Section

The module section provides contextual information and navigation for your asset through both default and custom modules:

#### Default Modules

Each asset type includes relevant default modules:

- **Assets Module** (Domains, Data Products, Glossary Terms): Shows data assets that belong to this domain, data product, or are tagged with this glossary term
- **Domains Module** (Domains only): Displays the hierarchy of child domains within this domain
- **Data Products Module** (Domains only): Lists all data products contained within this domain
- **Contents Module** (Glossary Term Groups only): Shows child glossary terms and term groups for easy hierarchy navigation
- **Related Terms Module** (Glossary Terms only): Lists all terms that share relationships with the current term
- **Lineage Module** (Datasets only): Provides a preview of the dataset's lineage graph, showing upstream and downstream dependencies
- **Columns Module** (Datasets only): Displays the dataset's column schema in a table format, giving quick access to column details without navigating to the Schema tab

#### Custom Modules

You can also add the same custom modules available on the home page:

- **Collection**: Curated lists of specific assets you want to highlight
- **Documentation**: Pin important documentation that users should see
- **Hierarchy**: Top-down view of assets organized by domains or glossary terms

<p align="center">
  <img
       width="70%"  
       src="https://raw.githubusercontent.com/datahub-project/static-assets/refs/heads/main/imgs/summary/summary-modules.png"
       alt="Summary page module examples"/>
</p>

## Enabling Asset Summaries

Asset Summaries are controlled by feature flags that need to be set on the GMS (Generalized Metadata Service) container:

- **`ASSET_SUMMARY_PAGE_V1`**: Controls Asset Summaries for Domains, Data Products, Glossary Terms, and Glossary Term Groups
- **`DATASET_SUMMARY_PAGE_V1`**: Controls Asset Summaries specifically for Datasets

To enable Asset Summaries in your DataHub instance, set the appropriate environment variable(s) to `true` on the GMS container:

```bash
# For logical assets (Domains, Data Products, Glossary Terms, Glossary Term Groups)
ASSET_SUMMARY_PAGE_V1=true

# For physical assets (Datasets)
DATASET_SUMMARY_PAGE_V1=true
```

You can enable one or both feature flags depending on which asset types you want to provide summary pages for.

## Customizing Asset Summaries

:::note
Customization is currently only supported in DataHub Cloud. DataHub Core will support out of the box summary pages with no way to customize.
:::

### Editing Summary Page Headers

To customize which properties appear in your asset's header:

1. Navigate to your asset's Summary tab
2. Click the **plus icon** in the header section to add new properties
3. Replace or remove existing properties by clicking their name

<p align="center">
  <img
       width="70%"  
       src="https://raw.githubusercontent.com/datahub-project/static-assets/refs/heads/main/imgs/summary/summary-edit-properties.png"
       alt="Edit header properties"/>
</p>

### Managing Documentation and Links

Add or update documentation and links directly on the Summary tab:

1. Click **"Edit Description"** icon on the right side of the "About" section header
2. Use the rich text editor to format your content
3. Click **"Add Link"** icon on the right side of the "About" section header
4. Organize links by editing or removing them as needed where they are listed

<p align="center">
  <img
       width="70%"  
       src="https://raw.githubusercontent.com/datahub-project/static-assets/refs/heads/main/imgs/summary/summary-edit-documentation.png"
       alt="Edit documentation section"/>
</p>

### Adding and Arranging Modules

Customize the module section to highlight the most important information:

1. Click the "plus" button below existing modules to browse available module types
2. Drag and drop modules to reorder them
3. Use the edit or remove options in the module menu to modify existing modules

<p align="center">
  <img
       width="70%"  
       src="https://raw.githubusercontent.com/datahub-project/static-assets/refs/heads/main/imgs/summary/summary-edit-modules.png"
       alt="Add module menu"/>
</p>

:::note Global Changes
Changes you make to an asset's Summary page are **visible to all users** who view that asset. Your customizations become the default experience for everyone accessing that domain, data product, glossary term, or dataset.
:::

## Permissions and Access Control

To customize Asset Summaries, users need the **"Manage Asset Summary"** privilege for the specific asset they want to edit. This permission can be configured through DataHub's policy editor alongside other access controls. By default, Admins, Editors, and asset owners will be granted this permission.

### Setting Up Permissions

1. Navigate to **Settings > Permissions > Policies**
2. Create or edit a policy to include the "Manage Asset Summary" privilege
3. Assign the policy to appropriate users or groups
4. Apply the policy to specific assets or asset types

This granular permission system ensures that only authorized users can modify how critical organizational assets are presented to the broader team.

## Best Practices

When customizing your Asset Summaries:

- **Focus on user needs**: Include properties and modules that help users understand and navigate your assets effectively
- **Keep it relevant**: Don't overcrowd the Summary page - prioritize the most important information
- **Update regularly**: Review and refresh your customizations as your assets and organization evolve
- **Consider your audience**: Tailor the presentation to match how your team typically uses these assets
- **Leverage modules strategically**: Use default modules to show relationships and custom modules to highlight specific collections or documentation

## Next Steps

Now that you understand Asset Summaries:

1. **Enable the feature**: Set the appropriate feature flags (`ASSET_SUMMARY_PAGE_V1` and/or `DATASET_SUMMARY_PAGE_V1`) on your GMS container
2. **Start with high-traffic assets**: Begin by customizing the Summary pages for your most frequently accessed domains, data products, and datasets
3. **Leverage dataset-specific modules**: For datasets, take advantage of the Lineage and Columns modules to provide users with immediate visibility into data dependencies and schema
4. **Gather feedback**: Ask users what information would be most helpful to see on Summary pages
5. **Iterate based on usage**: Monitor how users interact with your customized summaries and adjust accordingly
6. **Scale thoughtfully**: Apply learnings from your initial customizations to other assets in your organization

Asset Summaries are designed to evolve with your organization's needs, providing the flexibility to create discovery experiences that truly serve your users while maintaining the structure that makes DataHub powerful.
